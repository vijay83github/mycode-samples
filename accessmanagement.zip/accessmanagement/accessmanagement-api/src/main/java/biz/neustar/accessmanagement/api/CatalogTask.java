package biz.neustar.accessmanagement.api;

public class CatalogTask {

    private String userName;
    private String number;

    public void setNumber(String number) {
        this.number = number;
    }

    public String getUserName() {
        return userName;
    }

    public String getNumber() {
        return number;
    }

    public void setUserName(String userName) {
        this.userName = userName;

    }

}
