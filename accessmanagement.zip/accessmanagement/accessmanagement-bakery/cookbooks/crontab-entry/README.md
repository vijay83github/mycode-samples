crontab-entry
=========

Chef cookbook for adding and removing entry in crontab
