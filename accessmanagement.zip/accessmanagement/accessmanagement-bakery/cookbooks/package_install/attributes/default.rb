#Define the attributes

default['package_install']['package_list'] = nil