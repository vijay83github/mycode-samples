mailutils
=========

Chef cookbook for installing mailutils
