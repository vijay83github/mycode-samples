# Set the default attributes

default['java_cert_install']['host'] = 'example.com'
default['java_cert_install']['port'] = 443
default['java_cert_install']['keytool_alias'] = 'example'
#default['java_cert_install']['keystore'] = '/usr/lib/jvm/default-java/jre/lib/security/cacerts'
default['java_cert_install']['keystore_pass'] = nil