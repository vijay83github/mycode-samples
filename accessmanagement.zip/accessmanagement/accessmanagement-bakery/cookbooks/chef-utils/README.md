Description
===========

Some common utils, including a fix the HOME environment variable for Chef

Requirements
============

Attributes
==========

Usage
=====

