(function() {
    return window.quova = {
        platform: {
	        admin: {
		        router: {},
	            collections: {},
	            models: {},
		        templates: {},
		        views: {}
            },
	        app: {},
	        view: {}
        }
    };

})();