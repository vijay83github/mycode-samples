define(['backbone'], function() {
	quova.platform.admin.models.BaseModel = Backbone.Model.extend({
		// placeholder base model
	});

	return quova.platform.admin.models.BaseModel;
});